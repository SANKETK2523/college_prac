// Write a Java Program to implement Command Design Pattern for Command Interface with execute() . Use this to create variety of commands for LightOnCommand, LightOffCommand, GarageDoorUpCommand, StereoOnWithCDComman.

import java.util.Scanner;

// Command interface
interface Command {
    void execute();
}

// Receiver Classes
class Light {
    public void on() {
        System.out.println("Light is ON");
    }
    public void off() {
        System.out.println("Light is OFF");
    }
}

class GarageDoor {
    public void up() {
        System.out.println("Garage door is OPEN");
    }
}

class Stereo {
    public void on() {
        System.out.println("Stereo is ON");
    }
    public void setCD() {
        System.out.println("Stereo is set to CD mode");
    }
    public void setVolume(int level) {
        System.out.println("Stereo volume set to " + level);
    }
}

// Concrete Command Classes
class LightOnCommand implements Command {
    private Light light;
    public LightOnCommand(Light light) { this.light = light; }
    public void execute() { light.on(); }
}

class LightOffCommand implements Command {
    private Light light;
    public LightOffCommand(Light light) { this.light = light; }
    public void execute() { light.off(); }
}

class GarageDoorUpCommand implements Command {
    private GarageDoor door;
    public GarageDoorUpCommand(GarageDoor door) { this.door = door; }
    public void execute() { door.up(); }
}

class StereoOnWithCDCommand implements Command {
    private Stereo stereo;
    public StereoOnWithCDCommand(Stereo stereo) { this.stereo = stereo; }
    public void execute() {
        stereo.on();
        stereo.setCD();
        stereo.setVolume(11);
    }
}

// Invoker: Remote Control
class RemoteControl {
    private Command command;
    public void setCommand(Command command) { this.command = command; }
    public void pressButton() { command.execute(); }
}

// Test Class with Switch Menu
public class RemoteControlMenuTest {
    public static void main(String[] args) {
        Scanner sc = new Scanner(System.in);

        // Receivers
        Light light = new Light();
        GarageDoor garageDoor = new GarageDoor();
        Stereo stereo = new Stereo();

        // Commands
        Command lightOn = new LightOnCommand(light);
        Command lightOff = new LightOffCommand(light);
        Command garageUp = new GarageDoorUpCommand(garageDoor);
        Command stereoOn = new StereoOnWithCDCommand(stereo);

        // Remote
        RemoteControl remote = new RemoteControl();

        // Menu loop
        while (true) {
            System.out.println("\n--- Remote Control Menu ---");
            System.out.println("1. Turn Light ON");
            System.out.println("2. Turn Light OFF");
            System.out.println("3. Open Garage Door");
            System.out.println("4. Turn Stereo ON with CD");
            System.out.println("5. Exit");
            System.out.print("Enter your choice: ");

            int choice = sc.nextInt();

            switch (choice) {
                case 1:
                    remote.setCommand(lightOn);
                    remote.pressButton();
                    break;
                case 2:
                    remote.setCommand(lightOff);
                    remote.pressButton();
                    break;
                case 3:
                    remote.setCommand(garageUp);
                    remote.pressButton();
                    break;
                case 4:
                    remote.setCommand(stereoOn);
                    remote.pressButton();
                    break;
                case 5:
                    System.out.println("Exiting...");
                    System.exit(0);
                default:
                    System.out.println("Invalid choice! Please try again.");
            }
        }
    }
}


// --- Remote Control Menu ---
// 1. Turn Light ON
// 2. Turn Light OFF
// 3. Open Garage Door
// 4. Turn Stereo ON with CD
// 5. Exit
// Enter your choice: 1
// Light is ON

// Enter your choice: 3
// Garage door is OPEN
