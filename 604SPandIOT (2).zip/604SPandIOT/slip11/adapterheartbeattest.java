// Write a java program to implement Adapter pattern to design Heart Model to Beat Model

import java.util.*;

// HeartModel class (the adaptee)
class heartmodel {
    private int heartRate = 72; // default heart rate

    public int getHeartRate() {
        return heartRate;
    }

    public void increaseRate() {
        heartRate += 1;
    }

    public void decreaseRate() {
        heartRate -= 1;
    }

    public void on() {
        System.out.println("Heart started beating...");
    }

    public void off() {
        System.out.println("Heart stopped.");
    }
}

// Target interface (what BeatModel expects)
interface ibeatmodel {
    void start();
    void stop();
    int getHeartRate();
}

// Adapter class: adapts HeartModel to IBeatModel
class heartadapter implements ibeatmodel {
    private heartmodel heart;

    public heartadapter(heartmodel heart) {
        this.heart = heart;
    }

    @Override
    public void start() {
        heart.on();
    }

    @Override
    public void stop() {
        heart.off();
    }

    @Override
    public int getHeartRate() {
        return heart.getHeartRate();
    }
}

// Test class
public class adapterheartbeattest {
    public static void main(String[] args) {
        // Original HeartModel
        heartmodel heart = new heartmodel();

        // Adapter to make HeartModel compatible with IBeatModel
        ibeatmodel beatModel = new heartadapter(heart);

        // Use BeatModel interface
        beatModel.start();
        System.out.println("Current Heart Rate: " + beatModel.getHeartRate() + " bpm");

        // Simulate heartbeat changes
        heart.increaseRate();
        System.out.println("Heart Rate after increase: " + beatModel.getHeartRate() + " bpm");

        heart.decreaseRate();
        System.out.println("Heart Rate after decrease: " + beatModel.getHeartRate() + " bpm");

        beatModel.stop();
    }
}


// PS C:\Users\yashm\Desktop\desktop\SYMScCS\604SPandIOT>  c:; cd 'c:\Users\yashm\Desktop\desktop\SYMScCS\604SPandIOT'; & 'C:\Program Files\Java\jdk-25\bin\java.exe' '-XX:+ShowCodeDetailsInExceptionMessages' '-cp' 'C:\Users\yashm\AppData\Roaming\Code\User\workspaceStorage\66bf1f4e7847ee8c08d45ee593727460\redhat.java\jdt_ws\604SPandIOT_3b7f9902\bin' 'adapterheartbeattest' 
// Heart started beating...
// Current Heart Rate: 72 bpm
// Heart Rate after increase: 73 bpm
// Heart Rate after decrease: 72 bpm
// Heart stopped.