// Write a Java Program to implement Decorator Pattern for interface Car to define the assemble() method and then decorate it to Sports car and Luxury Car

import java.util.Scanner;

// Step 1: Car Interface
interface Car {
    void assemble();
}

// Step 2: Basic Car Implementation
class BasicCar implements Car {
    @Override
    public void assemble() {
        System.out.println("Basic Car.");
    }
}

// Step 3: Decorator Class
class CarDecorator implements Car {
    protected Car car;

    public CarDecorator(Car car) {
        this.car = car;
    }

    @Override
    public void assemble() {
        this.car.assemble();
    }
}

// Step 4: Concrete Decorators
class SportsCar extends CarDecorator {
    public SportsCar(Car car) { super(car); }

    @Override
    public void assemble() {
        super.assemble();
        System.out.println("Adding features of Sports Car.");
    }
}

class LuxuryCar extends CarDecorator {
    public LuxuryCar(Car car) { super(car); }

    @Override
    public void assemble() {
        super.assemble();
        System.out.println("Adding features of Luxury Car.");
    }
}

// Step 5: Interactive Test Class
public class CarDecoratorInteractive {
    public static void main(String[] args) {
        Scanner sc = new Scanner(System.in);

        while (true) {
            System.out.println("\n--- Car Assembly Menu ---");
            System.out.println("1. Assemble Basic Car");
            System.out.println("2. Assemble Sports Car");
            System.out.println("3. Assemble Luxury Car");
            System.out.println("4. Assemble Sports Luxury Car");
            System.out.println("5. Exit");
            System.out.print("Enter your choice: ");

            int choice = sc.nextInt();

            Car car;

            switch (choice) {
                case 1:
                    car = new BasicCar();
                    System.out.println("\nAssembling Basic Car:");
                    car.assemble();
                    break;
                case 2:
                    car = new SportsCar(new BasicCar());
                    System.out.println("\nAssembling Sports Car:");
                    car.assemble();
                    break;
                case 3:
                    car = new LuxuryCar(new BasicCar());
                    System.out.println("\nAssembling Luxury Car:");
                    car.assemble();
                    break;
                case 4:
                    car = new SportsCar(new LuxuryCar(new BasicCar()));
                    System.out.println("\nAssembling Sports Luxury Car:");
                    car.assemble();
                    break;
                case 5:
                    System.out.println("Exiting...");
                    System.exit(0);
                default:
                    System.out.println("Invalid choice! Try again.");
            }
        }
    }
}
