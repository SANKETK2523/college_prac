// Write a JAVA Program to implement built-in support (java.util.Observable) Weather station with members temperature, humidity, pressure and methods mesurmentsChanged(), setMesurment(), getTemperature(), getHumidity(), getPressure()

import java.util.Observable;
import java.util.Observer;

// WeatherStation class extends Observable
class weatherstation extends Observable {
    private float temperature;
    private float humidity;
    private float pressure;

    // Called when measurements change
    public void measurementschanged() {
        setChanged();       // mark as changed
        notifyObservers();  // notify all observers
    }

    // Set new measurements
    public void setmeasurements(float temperature, float humidity, float pressure) {
        this.temperature = temperature;
        this.humidity = humidity;
        this.pressure = pressure;
        measurementschanged();
    }

    // Getter methods
    public float gettemperature() {
        return temperature;
    }

    public float gethumidity() {
        return humidity;
    }

    public float getpressure() {
        return pressure;
    }
}

// Observer class to display data
class display implements Observer {
    public display(Observable obs) {
        obs.addObserver(this); // register as observer
    }

    @Override
    public void update(Observable obs, Object arg) {
        if (obs instanceof weatherstation) {
            weatherstation ws = (weatherstation) obs;
            System.out.println("Temperature: " + ws.gettemperature() + "°C");
            System.out.println("Humidity: " + ws.gethumidity() + "%");
            System.out.println("Pressure: " + ws.getpressure() + " hPa");
            System.out.println("----------------------------");
        }
    }
}

// Test class with main method
public class weatherstationtest {
    public static void main(String[] args) {
        // Create weather station
        weatherstation ws = new weatherstation();

        // Create display and register as observer
        display d = new display(ws);

        // Set some measurements
        ws.setmeasurements(30.5f, 65.0f, 1013.0f);
        ws.setmeasurements(32.0f, 70.0f, 1010.5f);
        ws.setmeasurements(28.5f, 60.0f, 1012.0f);
    }
}


// PS C:\Users\yashm\Desktop\desktop\SYMSc CS\604SPandIOT\slip3> javac weatherstationtest.java
// Note: weatherstationtest.java uses or overrides a deprecated API.
// Note: Recompile with -Xlint:deprecation for details.
// PS C:\Users\yashm\Desktop\desktop\SYMSc CS\604SPandIOT\slip3> java -cp "C:\Users\yashm\Desktop\desktop\SYMSc CS\604SPandIOT\slip3" weatherstationtest
// Temperature: 30.5°C
// Humidity: 65.0%
// Pressure: 1013.0 hPa
// ----------------------------
// Temperature: 32.0°C
// Humidity: 70.0%
// Pressure: 1010.5 hPa
// ----------------------------
// Temperature: 28.5°C
// Humidity: 60.0%
// Pressure: 1012.0 hPa
// ----------------------------