// Write a Java Program to implement State Pattern for Gumball Machine.
// Create instance variable that holds current state from there, we just need to handle all actions, behaviors and state transition that can happen

import java.util.Scanner;

// State Interface
interface State {
    void insertQuarter();
    void ejectQuarter();
    void turnCrank();
}

// Gumball Machine (Context)
class GumballMachine {
    private State state;
    private int count;

    // States
    private State noQuarter = new NoQuarterState(this);
    private State hasQuarter = new HasQuarterState(this);
    private State soldOut = new SoldOutState(this);
    private State sold = new SoldState(this);

    public GumballMachine(int numberOfGumballs) {
        this.count = numberOfGumballs;
        state = (numberOfGumballs > 0) ? noQuarter : soldOut;
    }

    // Action methods delegate to current state
    public void insertQuarter() { state.insertQuarter(); }
    public void ejectQuarter() { state.ejectQuarter(); }
    public void turnCrank() { state.turnCrank(); }

    // Helper methods
    void setState(State state) { this.state = state; }
    void releaseBall() {
        System.out.println("A gumball comes rolling out...");
        if (count > 0) count--;
    }
    int getCount() { return count; }

    State getNoQuarterState() { return noQuarter; }
    State getHasQuarterState() { return hasQuarter; }
    State getSoldState() { return sold; }
    State getSoldOutState() { return soldOut; }
}

// Concrete States
class NoQuarterState implements State {
    GumballMachine machine;
    public NoQuarterState(GumballMachine machine) { this.machine = machine; }

    public void insertQuarter() {
        System.out.println("You inserted a quarter.");
        machine.setState(machine.getHasQuarterState());
    }
    public void ejectQuarter() { System.out.println("You haven't inserted a quarter."); }
    public void turnCrank() { System.out.println("You turned, but there's no quarter."); }
}

class HasQuarterState implements State {
    GumballMachine machine;
    public HasQuarterState(GumballMachine machine) { this.machine = machine; }

    public void insertQuarter() { System.out.println("You can't insert another quarter."); }
    public void ejectQuarter() {
        System.out.println("Quarter returned.");
        machine.setState(machine.getNoQuarterState());
    }
    public void turnCrank() {
        System.out.println("You turned the crank...");
        machine.setState(machine.getSoldState());
    }
}

class SoldState implements State {
    GumballMachine machine;
    public SoldState(GumballMachine machine) { this.machine = machine; }

    public void insertQuarter() { System.out.println("Please wait, gumball is coming."); }
    public void ejectQuarter() { System.out.println("You already turned the crank."); }
    public void turnCrank() { System.out.println("Turning twice doesn't get another gumball."); }

    public void dispense() {
        machine.releaseBall();
        if (machine.getCount() > 0)
            machine.setState(machine.getNoQuarterState());
        else
            machine.setState(machine.getSoldOutState());
    }

    // Automatically dispense when turning crank
    public void turnCrank() {
        System.out.println("You turned the crank...");
        dispense();
    }
}

class SoldOutState implements State {
    GumballMachine machine;
    public SoldOutState(GumballMachine machine) { this.machine = machine; }

    public void insertQuarter() { System.out.println("Machine is sold out."); }
    public void ejectQuarter() { System.out.println("No quarter to eject."); }
    public void turnCrank() { System.out.println("Machine is sold out."); }
}

// Test Class
public class SimpleGumballMachineTest {
    public static void main(String[] args) {
        Scanner sc = new Scanner(System.in);
        GumballMachine machine = new GumballMachine(3);

        while (true) {
            System.out.println("\n--- Gumball Machine ---");
            System.out.println("1. Insert Quarter");
            System.out.println("2. Eject Quarter");
            System.out.println("3. Turn Crank");
            System.out.println("4. Exit");
            System.out.print("Enter your choice: ");

            int choice = sc.nextInt();

            switch (choice) {
                case 1: machine.insertQuarter(); break;
                case 2: machine.ejectQuarter(); break;
                case 3: machine.turnCrank(); break;
                case 4: System.out.println("Exiting..."); System.exit(0);
                default: System.out.println("Invalid choice!");
            }
        }
    }
}


// --- Gumball Machine ---
// 1. Insert Quarter
// 2. Eject Quarter
// 3. Turn Crank
// 4. Exit
// Enter your choice: 

// Enter your choice: 1
// // You inserted a quarter.

// Enter your choice: 2
// // Quarter returned.

// Enter your choice: 3
// // You turned, but there's no quarter.