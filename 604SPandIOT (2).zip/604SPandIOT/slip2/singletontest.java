// Write a Java Program to implement Singleton pattern for multithreading

// Singleton class
class singleton {
    // static variable to hold the single instance
    private static singleton instance;

    // private constructor prevents instantiation from other classes
    private singleton() {
        System.out.println("Singleton instance created");
    }

    // synchronized method ensures thread safety
    public static synchronized singleton getinstance() {
        if (instance == null) {
            instance = new singleton();
        }
        return instance;
    }

    // sample method
    public void showmessage() {
        System.out.println("Hello from singleton!");
    }
}

// Test class
public class singletontest {
    public static void main(String[] args) {

        // Runnable task for threads
        Runnable task = () -> {
            singleton s = singleton.getinstance();
            s.showmessage();
        };

        // creating threads
        Thread t1 = new Thread(task);
        Thread t2 = new Thread(task);

        // start threads
        t1.start();
        t2.start();
    }
}
