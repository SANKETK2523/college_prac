// Write a Java Program to implement Strategy Pattern for Duck Behavior. Create instance variable that holds current state of Duck from there, we just need to handle all Flying Behaviors and Quack Behavior

import java.util.Scanner;

// Strategy Interfaces
interface FlyBehavior {
    void fly();
}

interface QuackBehavior {
    void quack();
}

// Concrete Flying Behaviors
class FlyWithWings implements FlyBehavior {
    public void fly() { System.out.println("I'm flying with wings!"); }
}

class FlyNoWay implements FlyBehavior {
    public void fly() { System.out.println("I can't fly."); }
}

// Concrete Quacking Behaviors
class Quack implements QuackBehavior {
    public void quack() { System.out.println("Quack!"); }
}

class Squeak implements QuackBehavior {
    public void quack() { System.out.println("Squeak!"); }
}

class MuteQuack implements QuackBehavior {
    public void quack() { System.out.println("<< Silence >>"); }
}

// Duck Class
class Duck {
    private FlyBehavior flyBehavior;
    private QuackBehavior quackBehavior;
    private String name;

    public Duck(String name, FlyBehavior flyBehavior, QuackBehavior quackBehavior) {
        this.name = name;
        this.flyBehavior = flyBehavior;
        this.quackBehavior = quackBehavior;
    }

    public void performFly() { flyBehavior.fly(); }
    public void performQuack() { quackBehavior.quack(); }

    public void setFlyBehavior(FlyBehavior fb) { flyBehavior = fb; }
    public void setQuackBehavior(QuackBehavior qb) { quackBehavior = qb; }

    public void display() { System.out.println("I am " + name); }
}

// Test Class with Switch Case Menu
public class DuckStrategyMenu {
    public static void main(String[] args) {
        Scanner sc = new Scanner(System.in);

        // Create ducks
        Duck mallard = new Duck("Mallard Duck", new FlyWithWings(), new Quack());
        Duck rubber = new Duck("Rubber Duck", new FlyNoWay(), new Squeak());

        while (true) {
            System.out.println("\n--- Duck Actions Menu ---");
            System.out.println("1. Mallard Duck Fly");
            System.out.println("2. Mallard Duck Quack");
            System.out.println("3. Rubber Duck Fly");
            System.out.println("4. Rubber Duck Quack");
            System.out.println("5. Make Rubber Duck Fly With Wings");
            System.out.println("6. Exit");
            System.out.print("Enter your choice: ");

            int choice = sc.nextInt();

            switch (choice) {
                case 1:
                    mallard.display();
                    mallard.performFly();
                    break;
                case 2:
                    mallard.display();
                    mallard.performQuack();
                    break;
                case 3:
                    rubber.display();
                    rubber.performFly();
                    break;
                case 4:
                    rubber.display();
                    rubber.performQuack();
                    break;
                case 5:
                    rubber.setFlyBehavior(new FlyWithWings());
                    System.out.println("Rubber Duck learned to fly!");
                    break;
                case 6:
                    System.out.println("Exiting...");
                    System.exit(0);
                    break;
                default:
                    System.out.println("Invalid choice! Try again.");
            }
        }
    }
}


// --- Duck Actions Menu ---
// 1. Mallard Duck Fly
// 2. Mallard Duck Quack
// 3. Rubber Duck Fly
// 4. Rubber Duck Quack
// 5. Make Rubber Duck Fly With Wings
// 6. Exit
// Enter your choice: 3
// I am Rubber Duck
// I can't fly.

// Enter your choice: 5
// Rubber Duck learned to fly!

// Enter your choice: 3
// I am Rubber Duck
// I'm flying with wings!
