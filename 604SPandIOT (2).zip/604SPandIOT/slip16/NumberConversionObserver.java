// Write a Java Program to implement Observer Design Pattern for number conversion. Accept a number in Decimal form and represent it in Hexadecimal, Octal and Binary. Change the Number and it reflects in other forms also

import java.util.ArrayList;
import java.util.List;
import java.util.Scanner;

// Step 1: Observer Interface
interface Observer {
    void update(int number);
}

// Step 2: Concrete Observers
class HexObserver implements Observer {
    @Override
    public void update(int number) {
        System.out.println("Hexadecimal: " + Integer.toHexString(number).toUpperCase());
    }
}

class OctalObserver implements Observer {
    @Override
    public void update(int number) {
        System.out.println("Octal: " + Integer.toOctalString(number));
    }
}

class BinaryObserver implements Observer {
    @Override
    public void update(int number) {
        System.out.println("Binary: " + Integer.toBinaryString(number));
    }
}

// Step 3: Subject Class
class NumberSubject {
    private List<Observer> observers = new ArrayList<>();
    private int number;

    public void attach(Observer observer) {
        observers.add(observer);
    }

    public void detach(Observer observer) {
        observers.remove(observer);
    }

    public void setNumber(int number) {
        this.number = number;
        notifyAllObservers();
    }

    private void notifyAllObservers() {
        for (Observer observer : observers) {
            observer.update(number);
        }
    }
}

// Step 4: Test Class with Switch Case
public class NumberConversionObserver {
    public static void main(String[] args) {
        Scanner sc = new Scanner(System.in);
        NumberSubject subject = new NumberSubject();

        // Attach observers
        subject.attach(new HexObserver());
        subject.attach(new OctalObserver());
        subject.attach(new BinaryObserver());

        while (true) {
            System.out.print("\nEnter a decimal number (or -1 to exit): ");
            int num = sc.nextInt();
            if (num == -1) {
                System.out.println("Exiting...");
                break;
            }
            subject.setNumber(num); // Updates all observers automatically
        }
    }
}


// Enter a decimal number (or -1 to exit): 25
// Hexadecimal: 19
// Octal: 31
// Binary: 11001

// Enter a decimal number (or -1 to exit): 10
// Hexadecimal: A
// Octal: 12
// Binary: 1010

// Enter a decimal number (or -1 to exit): -1
// Exiting...