// Write a Java Program to implement command pattern to test Remote Control

import java.util.Scanner;

// Step 1: The Command Interface
interface Command {
    void execute();
}

// Step 2: Receiver Class (Actual Device)
class Light {
    public void on() {
        System.out.println("Light is ON");
    }

    public void off() {
        System.out.println("Light is OFF");
    }
}

// Step 3: Concrete Command Classes
class LightOnCommand implements Command {
    private Light light;

    public LightOnCommand(Light light) {
        this.light = light;
    }

    public void execute() {
        light.on();
    }
}

class LightOffCommand implements Command {
    private Light light;

    public LightOffCommand(Light light) {
        this.light = light;
    }

    public void execute() {
        light.off();
    }
}

// Step 4: Invoker (The Remote Control)
class RemoteControl {
    private Command command;

    public void setCommand(Command command) {
        this.command = command;
    }

    public void pressButton() {
        if (command != null)
            command.execute();
        else
            System.out.println("No command set!");
    }
}

// Step 5: Test Class (Main Program with Switch Cases)
public class RemoteControlTest {
    public static void main(String[] args) {
        Scanner sc = new Scanner(System.in);

        // Create receiver
        Light livingRoomLight = new Light();

        // Create commands
        Command lightOn = new LightOnCommand(livingRoomLight);
        Command lightOff = new LightOffCommand(livingRoomLight);

        // Create invoker
        RemoteControl remote = new RemoteControl();

        // Menu-driven program
        while (true) {
            System.out.println("\n--- Remote Control ---");
            System.out.println("1. Turn Light ON");
            System.out.println("2. Turn Light OFF");
            System.out.println("3. Exit");
            System.out.print("Enter your choice: ");
            int choice = sc.nextInt();

            switch (choice) {
                case 1:
                    remote.setCommand(lightOn);
                    remote.pressButton();
                    break;
                case 2:
                    remote.setCommand(lightOff);
                    remote.pressButton();
                    break;
                case 3:
                    System.out.println("Exiting...");
                    System.exit(0);
                    break;
                default:
                    System.out.println("Invalid choice! Please try again.");
            }
        }
    }
}


// --- Remote Control ---
// 1. Turn Light ON
// 2. Turn Light OFF
// 3. Exit
// Enter your choice: 1
// Light is ON

// Enter your choice: 2
// Light is OFF
