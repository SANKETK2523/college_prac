// Write a Java Program to implement an Adapter design pattern in mobile charger. Define two classes – Volt (to measure volts) and Socket (producing constant volts of 120V). Build an adapter that can produce 3 volts, 12 volts and default 120 volts. Implements Adapter pattern using Class Adapter

// Volt class to hold voltage value
class volt {
    private int volts;

    public volt(int volts) {
        this.volts = volts;
    }

    public int getvolts() {
        return volts;
    }

    public void setvolts(int volts) {
        this.volts = volts;
    }
}

// Socket class producing default 120V
class socket {
    public volt getvolt() {
        return new volt(120);
    }
}

// Target interface expected by mobile devices
interface itarget {
    volt get3volt();
    volt get12volt();
    volt get120volt();
}

// Class Adapter: adapts Socket to ITarget
class socketadapter extends socket implements itarget {

    // Converts 120V to 3V
    @Override
    public volt get3volt() {
        volt v = getvolt();
        return convertvolt(v, 40); // 120V / 40 = 3V
    }

    // Converts 120V to 12V
    @Override
    public volt get12volt() {
        volt v = getvolt();
        return convertvolt(v, 10); // 120V / 10 = 12V
    }

    // Returns default 120V
    @Override
    public volt get120volt() {
        return getvolt();
    }

    // Helper method to convert voltage
    private volt convertvolt(volt v, int divisor) {
        return new volt(v.getvolts() / divisor);
    }
}

// Test class
public class classadaptertest {
    public static void main(String[] args) {
        itarget adapter = new socketadapter();

        System.out.println("3 volts: " + adapter.get3volt().getvolts() + "V");
        System.out.println("12 volts: " + adapter.get12volt().getvolts() + "V");
        System.out.println("120 volts: " + adapter.get120volt().getvolts() + "V");
    }
}




// 3 volts: 3V
// 12 volts: 12V
// 120 volts: 120V