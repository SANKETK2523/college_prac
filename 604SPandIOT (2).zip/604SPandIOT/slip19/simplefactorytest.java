// Write a Java Program to implement Factory method for Pizza Store with createPizza(), orederPizza(), prepare(), Bake(), cut(), box(). Use this to create variety of pizza’s
// like NyStyleCheesePizza, ChicagoStyleCheesePizza etc.

// Base Pizza class
class pizza {
    String name;

    void prepare() {
        System.out.println("Preparing " + name);
    }

    void bake() {
        System.out.println("Baking " + name);
    }

    void cut() {
        System.out.println("Cutting " + name);
    }

    void box() {
        System.out.println("Boxing " + name);
    }
}

// Concrete Pizzas
class nystylecheesepizza extends pizza {
    nystylecheesepizza() {
        name = "NY Style Cheese Pizza";
    }
}

class chicagostylecheesepizza extends pizza {
    chicagostylecheesepizza() {
        name = "Chicago Style Cheese Pizza";
    }
}

// Pizza Store
class pizzastore {
    pizza createpizza(String type, String style) {
        if (style.equalsIgnoreCase("NY") && type.equalsIgnoreCase("cheese")) {
            return new nystylecheesepizza();
        } else if (style.equalsIgnoreCase("Chicago") && type.equalsIgnoreCase("cheese")) {
            return new chicagostylecheesepizza();
        } else {
            return null;
        }
    }

    pizza orderpizza(String type, String style) {
        pizza p = createpizza(type, style);
        if (p != null) {
            p.prepare();
            p.bake();
            p.cut();
            p.box();
        }
        return p;
    }
}

// Test class
public class simplefactorytest {
    public static void main(String[] args) {
        pizzastore store = new pizzastore();

        pizza p1 = store.orderpizza("cheese", "NY");
        System.out.println("Ordered a " + p1.name + "\n");

        pizza p2 = store.orderpizza("cheese", "Chicago");
        System.out.println("Ordered a " + p2.name);
    }
}

// Preparing NY Style Cheese Pizza
// Baking NY Style Cheese Pizza
// Cutting NY Style Cheese Pizza
// Boxing NY Style Cheese Pizza
// Ordered a NY Style Cheese Pizza

// Preparing Chicago Style Cheese Pizza
// Baking Chicago Style Cheese Pizza
// Cutting Chicago Style Cheese Pizza
// Boxing Chicago Style Cheese Pizza
// Ordered a Chicago Style Cheese Pizza