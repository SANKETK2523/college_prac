// This is not a correct program.

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;
import org.springframework.web.bind.annotation.*;
import java.util.*;

@SpringBootApplication
@RestController
@RequestMapping("/employees")
public class SimpleHrApp {

    // In-memory list to store employees
    private List<Employee> employees = new ArrayList<>();
    private long nextId = 1;

    public static void main(String[] args) {
        SpringApplication.run(SimpleHrApp.class, args);
    }

    // Employee class
    static class Employee {
        private long id;
        private String name;
        private String department;
        private double salary;

        public Employee() {} // default constructor

        public Employee(long id, String name, String department, double salary) {
            this.id = id;
            this.name = name;
            this.department = department;
            this.salary = salary;
        }

        // Getters and setters
        public long getId() { return id; }
        public void setId(long id) { this.id = id; }

        public String getName() { return name; }
        public void setName(String name) { this.name = name; }

        public String getDepartment() { return department; }
        public void setDepartment(String department) { this.department = department; }

        public double getSalary() { return salary; }
        public void setSalary(double salary) { this.salary = salary; }
    }

    // Get all employees
    @GetMapping
    public List<Employee> getAllEmployees() {
        return employees;
    }

    // Get employee by ID
    @GetMapping("/{id}")
    public Employee getEmployee(@PathVariable long id) {
        return employees.stream().filter(e -> e.getId() == id).findFirst().orElse(null);
    }

    // Add new employee
    @PostMapping
    public Employee addEmployee(@RequestBody Employee employee) {
        employee.setId(nextId++);
        employees.add(employee);
        return employee;
    }

    // Delete employee
    @DeleteMapping("/{id}")
    public String deleteEmployee(@PathVariable long id) {
        employees.removeIf(e -> e.getId() == id);
        return "Employee deleted with ID: " + id;
    }
}
