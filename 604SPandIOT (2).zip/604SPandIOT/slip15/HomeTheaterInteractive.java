// Write a Java Program to implement Facade Design Pattern for Home Theater

import java.util.Scanner;

// Subsystem Classes
class DVDPlayer {
    public void on() { System.out.println("DVD Player is ON"); }
    public void play(String movie) { System.out.println("Playing movie: " + movie); }
    public void off() { System.out.println("DVD Player is OFF"); }
}

class Projector {
    public void on() { System.out.println("Projector is ON"); }
    public void off() { System.out.println("Projector is OFF"); }
    public void setInput(DVDPlayer dvd) { System.out.println("Projector input set to DVD Player"); }
}

class Lights {
    public void dim(int level) { System.out.println("Lights dimmed to " + level + "%"); }
    public void on() { System.out.println("Lights are ON"); }
}

class SoundSystem {
    public void on() { System.out.println("Sound system is ON"); }
    public void setVolume(int level) { System.out.println("Volume set to " + level); }
    public void off() { System.out.println("Sound system is OFF"); }
}

// Facade Class
class HomeTheaterFacade {
    private DVDPlayer dvd;
    private Projector projector;
    private Lights lights;
    private SoundSystem sound;

    public HomeTheaterFacade(DVDPlayer dvd, Projector projector, Lights lights, SoundSystem sound) {
        this.dvd = dvd;
        this.projector = projector;
        this.lights = lights;
        this.sound = sound;
    }

    public void watchMovie(String movie) {
        System.out.println("\n--- Starting Movie ---");
        lights.dim(20);
        projector.on();
        projector.setInput(dvd);
        sound.on();
        sound.setVolume(30);
        dvd.on();
        dvd.play(movie);
    }

    public void endMovie() {
        System.out.println("\n--- Ending Movie ---");
        dvd.off();
        projector.off();
        sound.off();
        lights.on();
    }
}

// Test Class with Switch Case Menu
public class HomeTheaterInteractive {
    public static void main(String[] args) {
        Scanner sc = new Scanner(System.in);

        // Create subsystem objects
        DVDPlayer dvd = new DVDPlayer();
        Projector projector = new Projector();
        Lights lights = new Lights();
        SoundSystem sound = new SoundSystem();

        // Create Facade
        HomeTheaterFacade homeTheater = new HomeTheaterFacade(dvd, projector, lights, sound);

        while (true) {
            System.out.println("\n--- Home Theater Menu ---");
            System.out.println("1. Watch Movie");
            System.out.println("2. End Movie");
            System.out.println("3. Exit");
            System.out.print("Enter your choice: ");

            int choice = sc.nextInt();
            sc.nextLine(); // consume newline

            switch (choice) {
                case 1:
                    System.out.print("Enter movie name: ");
                    String movie = sc.nextLine();
                    homeTheater.watchMovie(movie);
                    break;
                case 2:
                    homeTheater.endMovie();
                    break;
                case 3:
                    System.out.println("Exiting Home Theater. Goodbye!");
                    System.exit(0);
                default:
                    System.out.println("Invalid choice! Try again.");
            }
        }
    }
}


// --- Home Theater Menu ---
// 1. Watch Movie
// 2. End Movie
// 3. Exit
// Enter your choice: 1
// Enter movie name: Avengers

// --- Starting Movie ---
// Lights dimmed to 20%
// Projector is ON
// Projector input set to DVD Player
// Sound system is ON
// Volume set to 30
// DVD Player is ON
// Playing movie: Avengers

// --- Home Theater Menu ---
// 1. Watch Movie
// 2. End Movie
// 3. Exit
// Enter your choice: 2

// --- Ending Movie ---
// DVD Player is OFF
// Projector is OFF
// Sound system is OFF
// Lights are ON
