// Write a Java Program to implement Abstract Factory Pattern for Shape interface.

import java.util.Scanner;

// Step 1: Shape Interface
interface Shape {
    void draw();
}

// Step 2: Concrete Shapes
class Circle implements Shape {
    @Override
    public void draw() {
        System.out.println("Drawing a Circle");
    }
}

class Rectangle implements Shape {
    @Override
    public void draw() {
        System.out.println("Drawing a Rectangle");
    }
}

class Square implements Shape {
    @Override
    public void draw() {
        System.out.println("Drawing a Square");
    }
}

// Step 3: Abstract Factory
interface AbstractFactory {
    Shape getShape(String shapeType);
}

// Step 4: Concrete Factory
class ShapeFactory implements AbstractFactory {
    @Override
    public Shape getShape(String shapeType) {
        if (shapeType == null) return null;

        switch (shapeType.toLowerCase()) {
            case "circle": return new Circle();
            case "rectangle": return new Rectangle();
            case "square": return new Square();
            default: return null;
        }
    }
}

// Step 5: Factory Producer
class FactoryProducer {
    public static AbstractFactory getFactory() {
        return new ShapeFactory();
    }
}

// Step 6: Interactive Test Class
public class AbstractFactoryInteractive {
    public static void main(String[] args) {
        Scanner sc = new Scanner(System.in);
        AbstractFactory shapeFactory = FactoryProducer.getFactory();

        while (true) {
            System.out.println("\n--- Shape Drawing Menu ---");
            System.out.println("1. Draw Circle");
            System.out.println("2. Draw Rectangle");
            System.out.println("3. Draw Square");
            System.out.println("4. Exit");
            System.out.print("Enter your choice: ");

            int choice = sc.nextInt();
            Shape shape = null;

            switch (choice) {
                case 1:
                    shape = shapeFactory.getShape("circle");
                    break;
                case 2:
                    shape = shapeFactory.getShape("rectangle");
                    break;
                case 3:
                    shape = shapeFactory.getShape("square");
                    break;
                case 4:
                    System.out.println("Exiting...");
                    System.exit(0);
                    break;
                default:
                    System.out.println("Invalid choice! Try again.");
                    continue;
            }

            if (shape != null) {
                shape.draw();
            }
        }
    }
}
