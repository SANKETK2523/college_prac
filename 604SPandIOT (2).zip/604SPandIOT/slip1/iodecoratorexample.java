// Write a Java Program to implement I/O Decorator for converting uppercase letters to lower case letters.

import java.io.*;

// custom decorator class that converts uppercase to lowercase
class lowercaseinputstream extends FilterInputStream {

    protected lowercaseinputstream(InputStream in) {
        super(in);
    }

    @Override
    public int read() throws IOException {
        int c = super.read();
        return (c == -1 ? c : Character.toLowerCase((char) c));
    }
}

public class iodecoratorexample {
    public static void main(String[] args) {
        try {
            System.out.println("enter text (use uppercase letters to test):");

            InputStream in = new lowercaseinputstream(System.in);

            int c;
            System.out.println("\nconverted to lowercase:");
            while ((c = in.read()) != -1) {
                System.out.print((char) c);
            }

            in.close();
        } catch (IOException e) {
            e.printStackTrace();
        }
    }
}


// converted to lowercase:
// HELLO YASH 
// hello yash