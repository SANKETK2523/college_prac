// Write a Java Program to implement undo command to test Ceiling fan.

import java.util.Scanner;

// Step 1: Command Interface
interface Command {
    void execute();
    void undo();
}

// Step 2: Receiver class (the actual fan)
class CeilingFan {
    private boolean isOn = false;

    public void turnOn() {
        isOn = true;
        System.out.println("Ceiling fan is turned ON.");
    }

    public void turnOff() {
        isOn = false;
        System.out.println("Ceiling fan is turned OFF.");
    }

    public boolean isOn() {
        return isOn;
    }
}

// Step 3: Concrete Command Classes
class FanOnCommand implements Command {
    private CeilingFan fan;

    public FanOnCommand(CeilingFan fan) {
        this.fan = fan;
    }

    public void execute() {
        fan.turnOn();
    }

    public void undo() {
        fan.turnOff();
    }
}

class FanOffCommand implements Command {
    private CeilingFan fan;

    public FanOffCommand(CeilingFan fan) {
        this.fan = fan;
    }

    public void execute() {
        fan.turnOff();
    }

    public void undo() {
        fan.turnOn();
    }
}

// Step 4: Invoker (Remote Control)
class RemoteControl {
    private Command command;
    private Command lastCommand;

    public void setCommand(Command command) {
        this.command = command;
    }

    public void pressButton() {
        command.execute();
        lastCommand = command; // save for undo
    }

    public void pressUndo() {
        System.out.println("Undoing last command...");
        if (lastCommand != null) {
            lastCommand.undo();
        } else {
            System.out.println("Nothing to undo!");
        }
    }
}

// Step 5: Client (Main Test)
public class CeilingFanCommandPattern {
    public static void main(String[] args) {
        Scanner sc = new Scanner(System.in);

        CeilingFan fan = new CeilingFan();
        Command fanOn = new FanOnCommand(fan);
        Command fanOff = new FanOffCommand(fan);

        RemoteControl remote = new RemoteControl();

        while (true) {
            System.out.println("\n1. Turn ON");
            System.out.println("2. Turn OFF");
            System.out.println("3. Undo");
            System.out.println("4. Exit");
            System.out.print("Enter your choice: ");
            int choice = sc.nextInt();

            switch (choice) {
                case 1:
                    remote.setCommand(fanOn);
                    remote.pressButton();
                    break;
                case 2:
                    remote.setCommand(fanOff);
                    remote.pressButton();
                    break;
                case 3:
                    remote.pressUndo();
                    break;
                case 4:
                    System.out.println("Exiting...");
                    System.exit(0);
                default:
                    System.out.println("Invalid choice!");
            }
        }
    }
}

// 1. Turn ON
// 2. Turn OFF
// 3. Undo
// 4. Exit
// Enter your choice: 1
// Ceiling fan is turned ON.

// Enter your choice: 2
// Ceiling fan is turned OFF.

// Enter your choice: 3
// Undoing last command...
// Ceiling fan is turned ON.
