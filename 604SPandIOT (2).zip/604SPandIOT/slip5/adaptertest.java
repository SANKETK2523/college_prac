// Write a Java Program to implement Adapter pattern for Enumeration iterator

import java.util.*;

// Adapter class: converts Enumeration to Iterator
class enumerationiteratoradapter<E> implements Iterator<E> {
    private Enumeration<E> enumeration;

    public enumerationiteratoradapter(Enumeration<E> enumeration) {
        this.enumeration = enumeration;
    }

    @Override
    public boolean hasNext() {
        return enumeration.hasMoreElements();
    }

    @Override
    public E next() {
        return enumeration.nextElement();
    }

    @Override
    public void remove() {
        throw new UnsupportedOperationException("Remove not supported");
    }
}

// Test class
public class adaptertest {
    public static void main(String[] args) {
        // Create a Vector (Enumeration works with Vector)
        Vector<String> vector = new Vector<>();
        vector.add("Apple");
        vector.add("Banana");
        vector.add("Cherry");

        // Get Enumeration from Vector
        Enumeration<String> enumeration = vector.elements();

        // Adapt Enumeration to Iterator using our Adapter
        Iterator<String> iterator = new enumerationiteratoradapter<>(enumeration);

        // Use Iterator to traverse elements
        System.out.println("Elements using Iterator:");
        while (iterator.hasNext()) {
            System.out.println(iterator.next());
        }
    }
}


// Elements using Iterator:
// Apple
// Banana
// Cherry